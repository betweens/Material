// default config
module.exports = {
  workers: 1
};
