// production config, it will load in production enviroment
module.exports = {
  workers: 0,
  staticHostUrl: 'https://static.no-forget.com',
};
