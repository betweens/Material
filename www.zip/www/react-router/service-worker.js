/**
 * Copyright 2016 Google Inc. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
*/

// DO NOT EDIT THIS GENERATED OUTPUT DIRECTLY!
// This file should be overwritten as part of your build process.
// If you need to extend the behavior of the generated service worker, the best approach is to write
// additional code and include it using the importScripts option:
//   https://github.com/GoogleChrome/sw-precache#importscripts-arraystring
//
// Alternatively, it's possible to make changes to the underlying template file and then use that as the
// new base for generating output, via the templateFilePath option:
//   https://github.com/GoogleChrome/sw-precache#templatefilepath-string
//
// If you go that route, make sure that whenever you update your sw-precache dependency, you reconcile any
// changes made to this original template file with your modified copy.

// This generated service worker JavaScript will precache your site's resources.
// The code needs to be saved in a .js file at the top-level of your site, and registered
// from your pages in order to be used. See
// https://github.com/googlechrome/sw-precache/blob/master/demo/app/js/service-worker-registration.js
// for an example of how you can register this script and handle various service worker events.

/* eslint-env worker, serviceworker */
/* eslint-disable indent, no-unused-vars, no-multiple-empty-lines, max-nested-callbacks, space-before-function-paren, quotes, comma-spacing */
'use strict';

var precacheConfig = [["https://www.no-forget.com/react-router/0.bundle-bd88adb5e52194d37728.js","a488f006774cfa6d653a0fbb659c5917"],["https://www.no-forget.com/react-router/1.bundle-11fd181ec58f8456ab69.js","fda07ff1d9c2d56e8a34b57cb1e1c2f0"],["https://www.no-forget.com/react-router/10.bundle-3f5a8ae10a0ac0578574.js","4f0b7229729663c3a0b935bcc679ded2"],["https://www.no-forget.com/react-router/11.bundle-59e73d8870109da93794.js","a3f541f9c25f3e7b908f025f328863ab"],["https://www.no-forget.com/react-router/12.bundle-a0e72c40255f0c0aa1e7.js","819db3b2cf5811ed6a5e398645c8a461"],["https://www.no-forget.com/react-router/13.bundle-b2ecd34243069ee2d161.js","cf535da1f92afed9b48528f613873176"],["https://www.no-forget.com/react-router/14.bundle-1db412fc36f6c310df89.js","f7cd5b7baeb154a47a57bd53726f9c45"],["https://www.no-forget.com/react-router/15.bundle-a0fd00a562ce3405369b.js","e2e9e58cf98eec4483e9184a323f7a5a"],["https://www.no-forget.com/react-router/16.bundle-2a02386c9c423764e9da.js","14fdc01ff044a2008ee5c22da099b2a3"],["https://www.no-forget.com/react-router/17.bundle-a410a99530f68972d901.js","495eefd3285809d9c2a62c63a35dd35c"],["https://www.no-forget.com/react-router/18.bundle-cadb688bc9f5acaa5c9a.js","0ef7616916ceb4a26d5092cca2cb361e"],["https://www.no-forget.com/react-router/19.bundle-da8134ef15040df13d59.js","fcf115dad0fa7873694a152a849d4383"],["https://www.no-forget.com/react-router/2.bundle-fcaafecd0b5bc8ad20c2.js","75119a116ac4052aaa1386be9a598f6d"],["https://www.no-forget.com/react-router/20.bundle-7ef99d761294b629f041.js","5afb556656b431542429c9eb83dcdef8"],["https://www.no-forget.com/react-router/21.bundle-d86a86bc6fb50ae8d18d.js","24e38c28f80584644711accc48209318"],["https://www.no-forget.com/react-router/22.bundle-9a2bd607ef0fcf13324e.js","95138d6a6076295c4d57796585949068"],["https://www.no-forget.com/react-router/23.bundle-0b67ee81eb30718593f8.js","1478b532a40691cd02be24712d216b38"],["https://www.no-forget.com/react-router/24.bundle-58b4fecd5b1761a2f272.js","7be45351a97c8416c58154641c953867"],["https://www.no-forget.com/react-router/25.bundle-70987d4d54aab2c46735.js","6a016039faa1da9535f66b1e95b9d27b"],["https://www.no-forget.com/react-router/26.bundle-c1d2376d5c276c252a8b.js","d587888d03caa7a8d190cf735bc7c550"],["https://www.no-forget.com/react-router/27.bundle-88f863dd3e688d45813f.js","795eea76569305abdf7f5a2a22b9d0f7"],["https://www.no-forget.com/react-router/28.bundle-22ddf232cadf3debeb35.js","56b0bf376926732be6125c416bd84f4d"],["https://www.no-forget.com/react-router/29.bundle-69da1cd857d0b7abb752.js","c69c5363cfa70511038d364c3fd411e4"],["https://www.no-forget.com/react-router/30.bundle-39c50fcecb4a75a56f6d.js","770a09d168ed0d3725c4ee2ea8e18eec"],["https://www.no-forget.com/react-router/31.bundle-aed297c34dcc1d61374c.js","610fb898d7e36dfe43aadd315dd61153"],["https://www.no-forget.com/react-router/32.bundle-18d088aa6888da1919ab.js","e0003a1619eb6ff9def4e540a267d1c5"],["https://www.no-forget.com/react-router/33.bundle-d8bac0289d2e4a9e63a0.js","137054f05cfa9d7a1547917c802a0f80"],["https://www.no-forget.com/react-router/34.bundle-753fc297cb7b21b7cb67.js","cff2a66048cd35d35f4fd6bdbed3fb0d"],["https://www.no-forget.com/react-router/35.bundle-9a39c6515daf60a18915.js","3e8b5b207b691a9520407702f11aaebc"],["https://www.no-forget.com/react-router/36.bundle-d92e8aa4be3c73d03263.js","243de4183972268218099e1f5f79c4e2"],["https://www.no-forget.com/react-router/37.bundle-f8f5847a9dc6c4cc05d2.js","54003a16ca1bd958af1d31fc3d0c8479"],["https://www.no-forget.com/react-router/38.bundle-c21c20e14bb26ae5f5fb.js","16e0ccca0d2f5daae2ccbfcdbbc4e588"],["https://www.no-forget.com/react-router/39.bundle-61db1a2eb0b13b705219.js","b611043a7d0abc5dab2e285e3267d606"],["https://www.no-forget.com/react-router/40.bundle-270205d61f2e2cb10550.js","081c31d7ab088b69c03494777e21d13b"],["https://www.no-forget.com/react-router/5.bundle-d97511f14f4b2422c3f5.js","8c9af2fef9d87bb164a387d4b8f0dc97"],["https://www.no-forget.com/react-router/6.bundle-e2adbde6d7b571a361c0.js","92d8ff546c2cd5573426be7caf5117be"],["https://www.no-forget.com/react-router/7.bundle-08e752be0024c002091f.js","11c029197d5f95cfc8cad2246e58173a"],["https://www.no-forget.com/react-router/8.bundle-fe43827340a3bc3cb1f5.js","15fe2d2bedd4c0a20006f892de156da7"],["https://www.no-forget.com/react-router/9.bundle-8182ff8ee50065ece76e.js","25a99c8e9b339ceaecdbcd960804f113"],["https://www.no-forget.com/react-router/android-chrome-144x144.png","0aa71a5783edc358767e6cb00795b329"],["https://www.no-forget.com/react-router/apple-touch-icon.png","59ce700521fe0556c5830fe58bf96c17"],["https://www.no-forget.com/react-router/b7372c7643a2efae0fdf961a949a29e5.png","b7372c7643a2efae0fdf961a949a29e5"],["https://www.no-forget.com/react-router/browserconfig.xml","5a8f27e7dd0c369028679223d0465728"],["https://www.no-forget.com/react-router/bundle-13ad4267a1a80678d7d5.js","a42a6b45555d13be7c8c72709e6cf7f9"],["https://www.no-forget.com/react-router/favicon-16x16.png","b94fcb5f7364b3e26ae6ede16b719ea3"],["https://www.no-forget.com/react-router/favicon-32x32.png","cfa43c1bad9c17b98614e7ff9aa596a9"],["https://www.no-forget.com/react-router/favicon.ico","f4706ad25b9e9ca9720932652ec342ca"],["https://www.no-forget.com/react-router/index.html","c3b34819a1f830330a2596334eb1178c"],["https://www.no-forget.com/react-router/manifest.json","63caf6242da7528888db67541292f0b5"],["https://www.no-forget.com/react-router/mstile-150x150.png","886bf4a2c7300bd9836059809a3089bf"],["https://www.no-forget.com/react-router/react-square.png","3342b3152ae96e4e16ca780cffc8d1bd"],["https://www.no-forget.com/react-router/safari-pinned-tab.svg","1146ba4a2a492be098bd76ecf45f9575"],["https://www.no-forget.com/react-router/vendor-a262d7a9e5de348b9333.js","e218975f14da0661f24fb35f31caca89"]];
var cacheName = 'sw-precache-v2-react-router-website-' + (self.registration ? self.registration.scope : '');


var ignoreUrlParametersMatching = [/^utm_/];



var addDirectoryIndex = function (originalUrl, index) {
    var url = new URL(originalUrl);
    if (url.pathname.slice(-1) === '/') {
      url.pathname += index;
    }
    return url.toString();
  };

var createCacheKey = function (originalUrl, paramName, paramValue,
                           dontCacheBustUrlsMatching) {
    // Create a new URL object to avoid modifying originalUrl.
    var url = new URL(originalUrl);

    // If dontCacheBustUrlsMatching is not set, or if we don't have a match,
    // then add in the extra cache-busting URL parameter.
    if (!dontCacheBustUrlsMatching ||
        !(url.toString().match(dontCacheBustUrlsMatching))) {
      url.search += (url.search ? '&' : '') +
        encodeURIComponent(paramName) + '=' + encodeURIComponent(paramValue);
    }

    return url.toString();
  };

var isPathWhitelisted = function (whitelist, absoluteUrlString) {
    // If the whitelist is empty, then consider all URLs to be whitelisted.
    if (whitelist.length === 0) {
      return true;
    }

    // Otherwise compare each path regex to the path of the URL passed in.
    var path = (new URL(absoluteUrlString)).pathname;
    return whitelist.some(function(whitelistedPathRegex) {
      return path.match(whitelistedPathRegex);
    });
  };

var stripIgnoredUrlParameters = function (originalUrl,
    ignoreUrlParametersMatching) {
    var url = new URL(originalUrl);

    url.search = url.search.slice(1) // Exclude initial '?'
      .split('&') // Split into an array of 'key=value' strings
      .map(function(kv) {
        return kv.split('='); // Split each 'key=value' string into a [key, value] array
      })
      .filter(function(kv) {
        return ignoreUrlParametersMatching.every(function(ignoredRegex) {
          return !ignoredRegex.test(kv[0]); // Return true iff the key doesn't match any of the regexes.
        });
      })
      .map(function(kv) {
        return kv.join('='); // Join each [key, value] array into a 'key=value' string
      })
      .join('&'); // Join the array of 'key=value' strings into a string with '&' in between each

    return url.toString();
  };


var hashParamName = '_sw-precache';
var urlsToCacheKeys = new Map(
  precacheConfig.map(function(item) {
    var relativeUrl = item[0];
    var hash = item[1];
    var absoluteUrl = new URL(relativeUrl, self.location);
    var cacheKey = createCacheKey(absoluteUrl, hashParamName, hash, false);
    return [absoluteUrl.toString(), cacheKey];
  })
);

function setOfCachedUrls(cache) {
  return cache.keys().then(function(requests) {
    return requests.map(function(request) {
      return request.url;
    });
  }).then(function(urls) {
    return new Set(urls);
  });
}

self.addEventListener('install', function(event) {
  event.waitUntil(
    caches.open(cacheName).then(function(cache) {
      return setOfCachedUrls(cache).then(function(cachedUrls) {
        return Promise.all(
          Array.from(urlsToCacheKeys.values()).map(function(cacheKey) {
            // If we don't have a key matching url in the cache already, add it.
            if (!cachedUrls.has(cacheKey)) {
              return cache.add(new Request(cacheKey, {
                credentials: 'same-origin',
                redirect: 'follow'
              }));
            }
          })
        );
      });
    }).then(function() {
      
      // Force the SW to transition from installing -> active state
      return self.skipWaiting();
      
    })
  );
});

self.addEventListener('activate', function(event) {
  var setOfExpectedUrls = new Set(urlsToCacheKeys.values());

  event.waitUntil(
    caches.open(cacheName).then(function(cache) {
      return cache.keys().then(function(existingRequests) {
        return Promise.all(
          existingRequests.map(function(existingRequest) {
            if (!setOfExpectedUrls.has(existingRequest.url)) {
              return cache.delete(existingRequest);
            }
          })
        );
      });
    }).then(function() {
      
      return self.clients.claim();
      
    })
  );
});


self.addEventListener('fetch', function(event) {
  if (event.request.method === 'GET') {
    // Should we call event.respondWith() inside this fetch event handler?
    // This needs to be determined synchronously, which will give other fetch
    // handlers a chance to handle the request if need be.
    var shouldRespond;

    // First, remove all the ignored parameter and see if we have that URL
    // in our cache. If so, great! shouldRespond will be true.
    var url = stripIgnoredUrlParameters(event.request.url, ignoreUrlParametersMatching);
    shouldRespond = urlsToCacheKeys.has(url);

    // If shouldRespond is false, check again, this time with 'index.html'
    // (or whatever the directoryIndex option is set to) at the end.
    var directoryIndex = 'index.html';
    if (!shouldRespond && directoryIndex) {
      url = addDirectoryIndex(url, directoryIndex);
      shouldRespond = urlsToCacheKeys.has(url);
    }

    // If shouldRespond is still false, check to see if this is a navigation
    // request, and if so, whether the URL matches navigateFallbackWhitelist.
    var navigateFallback = '';
    if (!shouldRespond &&
        navigateFallback &&
        (event.request.mode === 'navigate') &&
        isPathWhitelisted([], event.request.url)) {
      url = new URL(navigateFallback, self.location).toString();
      shouldRespond = urlsToCacheKeys.has(url);
    }

    // If shouldRespond was set to true at any point, then call
    // event.respondWith(), using the appropriate cache key.
    if (shouldRespond) {
      event.respondWith(
        caches.open(cacheName).then(function(cache) {
          return cache.match(urlsToCacheKeys.get(url)).then(function(response) {
            if (response) {
              return response;
            }
            throw Error('The cached response that was expected is missing.');
          });
        }).catch(function(e) {
          // Fall back to just fetch()ing the request if some unexpected error
          // prevented the cached response from being valid.
          console.warn('Couldn\'t serve response for "%s" from cache: %O', event.request.url, e);
          return fetch(event.request);
        })
      );
    }
  }
});







