<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <meta name="theme-color" content="#000000">
    <link rel="manifest" href="/manifest.json">
    <link rel="shortcut icon" href="/favicon.ico">
    <title>不愿忘记</title>
</head>
<body>
 <p><a href="https://www.no-forget.com/material">material ui 中文版本</a></p>
<p><a href="https://www.no-forget.com/react-router">react-router-dom 中文文档</a></p> 
<p><a href="https://www.no-forget.com/AsiaTech/#/AsiaTech">论文工具</a></p>
<p><a href="https://www.no-forget.com/threeJs/#manual/introduction/Creating-a-scene">ThreesJS中文文档</a></p>
<?php
echo "多么简单的首页,哈哈哈";
?>
</body>
</html>
